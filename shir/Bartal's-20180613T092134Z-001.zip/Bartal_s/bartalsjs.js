function contactuspage(){
  document.getElementById("contactus").onclick{
    alert(hi);
      // document.getElementById("mainpage").style.display=none;
      // document.getElementById("contactpage").style.display=block;
    }
  }
